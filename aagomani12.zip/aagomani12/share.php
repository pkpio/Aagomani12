<div><iframe src="//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2Fpages%2FAagomani%2F206039309458269&amp;send=false&amp;layout=button_count&amp;width=450&amp;show_faces=false&amp;action=like&amp;colorscheme=light&amp;font=tahoma&amp;height=21&amp;appId=262803340451000" scrolling="no" frameborder="0" style="border:none; overflow:hidden; width:400px; height:20px;" allowTransparency="true"></iframe></div></br>

<!--<div id="fb-root"><script src="http://connect.facebook.net/en_US/all.js#appId=160030430746679&amp;xfbml=1"></script>
<fb:like href="http://www.facebook.com/pages/Aagomani/206039309458269" send="false" layout="button_count" width="76" show_faces="true" font="trebuchet ms"></fb:like>
</div>
<br />
-->
<div class="googleplusshare"> 
<!-- Place this tag where you want the +1 button to render -->
<g:plusone size="medium"></g:plusone>

<!-- Place this render call where appropriate -->
<script type="text/javascript">
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script> 
</div> 

<br />

<div class="twittershare"> 
<a href="http://twitter.com/share" class="twitter-share-button" data-text="Aagomani" data-count="horizontal" data-via="Aagomani">Tweet</a>
<script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script> 
</div>