<script>
$(document).ready(function() {
	  document.getElementById("loadingImage").style.visibility="hidden";})
</script>
<h1>HOME</h1>
<p>  &nbsp; &nbsp; &nbsp; &nbsp; Electrical Engineering Students Association (EESA), IIT Bombay unveils a grander version of its annual technical festival Aagomani in the field of <span class="blu"><b>Automobile electronics</b></span> on the <span class="blu"><b>3rd of March, 2012</b></span>.
Electronics drives the world - quite literally. The seventh edition of Aagomani brings to you 'just the right spark' to ignite your minds with ideas and concepts in automobile electonics that have set the world on fire. </p><br />

<div align="center">

<object width='425' height='344'> 
    <param name='movie' value='http://www.youtube.com/v/ajwGLDEIoGA?rel=0'> 
    <param name='type' value='application/x-shockwave-flash'> 
    <param name='allowfullscreen' value='true'> 
    <param name='allowscriptaccess' value='always'> 
    <param name="wmode" value="opaque" />
    <embed width='425' height='344'
            src='http://www.youtube.com/embed/ajwGLDEIoGA?rel=0'
            type='application/x-shockwave-flash'
            allowfullscreen='true'
            allowscriptaccess='always'
            wmode="opaque"
    ></embed> 
    </object> 

<!--<iframe width="420" height="315" src="http://www.youtube.com/embed/ajwGLDEIoGA?rel=0" frameborder="0" allowfullscreen></iframe>
	<!-- START OF THE PLAYER EMBEDDING TO COPY-PASTE -
	<div id="mediaplayer">JW Player goes here</div>
	
	<script type="text/javascript" src="video/jwplayer.js"></script>
	<script type="text/javascript">
		jwplayer("mediaplayer").setup({
			flashplayer: "video/player.swf",
			file: "video/aagomani.mp4",
			image: "video/preview.jpg"
		});
	</script>
	<!-- END OF THE PLAYER EMBEDDING -->
    </div>

<p><br/>  &nbsp; &nbsp; &nbsp; &nbsp; United by the common thread of exploiting electronics to bring about greater efficiency and mobility in transportation, competitions and workshops at Aagomani promise to hone your engineering skills.
Lectures by renowned academicians and professionals shall 'drive' home the potential of electronics to reshape the automobile industry.
Expose yourself to a day of information, intelligence and sheer innovation, and satisfy your right to be enthralled by the magical impact electronics has had on the evergreen realm of automobile engineering.</p>
</div>
  </p>