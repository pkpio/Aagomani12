<p>   Some other content <br />
With lectures from top levgerel executives 4je67uhue67yof leading wireless and telecom industry and 
academicians from renowned ter5g5tirg5erg5rtyg5rnstitutes like IIT Bombay, we aim to gain an in-depth knowledge of the upcoming technologies, trends and innovations in the ever so popular field of 
wireless.<br />5rjiujnuyr
 Aimed at both students and professioh6y so frequently. The need to stay ahead in the competition and create devices which live up to the needs and requirements of the new-age generation is the challenge that li65rtyhe65ry5yh6hes ahead</p>
</div>
  </p>