<p>   Electrical Engihgneering Students Association (EESA), IIT Bombay is organizing its annual 
technical fe5wg5tdeukwgbcde wvjrewbfdj,hbvkqwne dwe5rfd<br>
edejwvfh433gfhcve hnrevgbj,ygstival iygnygh65 the field of wireless and cellular technology. Aagomani 2009 is being 
held at Electrical Engineering Department, IIT Bombay on the 10th and 11th of October 
2009. <br />
With lectures from top level executives of leading wireless and telecom industry and 
academicians from renowny4h6yed institutes like IIT Bombay, we aim to gain an in-depth knowledge of the upcoming technologies, trends and innovations in the ever so popular field of 
wireless.<br />

</div>
  </p>