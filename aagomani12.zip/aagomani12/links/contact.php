<script>
$(document).ready(function() {
	  document.getElementById("loadingImage").style.visibility="hidden";})
</script>
 <h1>CONTACT</h1>
 <style>



 .h {letter-spacing: 1px;



font-size:13px;



line-height:24px;



margin-bottom: 15px;



color:000; text-align:left;



font-weight:normal;}



h3 {font-family: 'Prociono', serif;



font-size:14px;



line-height:27px;



color:#666;}



h2 {font-family: 'Prociono', serif;



font-size:17px;



line-height:42px;



color:#23586a;}



 .blu { font-weight:bold;}



 



 </style>



<p>



<table width="100%" cellspacing="0" cellpadding="0" style="margin-left:40px;">



  <tr valign="top">



    <td width="50%" style="text-align:left"><h2 style="color:#333; ">AAGOMANI TEAM</h2><br />



    <h3 style="margin-top:-10px;"><span class="blu" style= "font-size:16px;" >Nikhil Goyal</span> - Overall Coordinator</h3>
    
    <span class="h">nikhil@aagomani.org</span>



     <h3 style="margin-top:20px;"><span class="blu" style= "font-size:16px;">Y. Akshay </span> - Events Manager</h3>

	<span class="h">+91-9004280549</span><br>

    <span class="h">akshay@aagomani.org</span>



         <h3  style="margin-top:20px;" ><span class="blu" style= "font-size:16px;">Siddhant Khopkar</span> - Events Manager</h3>

	<span class="h">+91-9561948102</span><br>

    <span class="h">siddhant@aagomani.org</span>



         <h3  style="margin-top:20px;"><span class="blu" style= "font-size:16px;">Ankit Khandelwal</span> - Marketing Manager</h3>

	<span class="h">+91-9029374250</span><br>


    <span class="h">ankit@aagomani.org</span>



         <h3  style="margin-top:20px;"><span class="blu" style= "font-size:16px;">Abhijit Borkar</span> - Design and Publicity Manager</h3>

	<span class="h">+91-9730115473</span><br>

    <span class="h">abhijit@aagomani.org</span>



         <h3  style="margin-top:20px;"><span class="blu" style= "font-size:16px;">Rahul Shinde</span> - PR and Media Manager</h3>

	<span class="h">+91-9833713759</span><br>

    <span class="h">rahul@aagomani.org</span>



         <h3  style="margin-top:20px;" ><span class="blu" style= "font-size:16px;">Praveen Kumar Pendyala</span> - Web Design Manager</h3>

	<span class="h">+91-8828829765</span><br>

    <span class="h">praveen@aagomani.org</span>



    <br><br><br>



    



</td>







    <td>



    <h2 style="color:#333">EESA TEAM</h2><br />



    <h3 style="margin-top:-10px;"><span class="blu" style="font-size:16px;">Akshat Jain</span> - Department General Secretary</h3>



    <span class="h">akshat@aagomani.org</span>



     <h3 style="margin-top:20px;"><span class="blu" style= "font-size:16px;">Akshat Kharaya</span> - EESA General Secretary</h3>



    <span class="h">kharaya@aagomani.org</span>



         <h3  style="margin-top:20px;" ><span class="blu" style= "font-size:16px;">Amit Yadav</span> - EESA Joint Secretary</h3>



    <span class="h">amit@aagomani.org</span>



         <h3  style="margin-top:20px;"><span class="blu" style= "font-size:16px;">Prince Arya</span> - EESA Joint Secretary</h3>



    <span class="h">prince@aagomani.org</span>



         <h3  style="margin-top:20px;"><span class="blu" style= "font-size:16px;">Aditi Pohekar </span> - Department Design Secretary </h3>



    <span class="h">aditi@aagomani.org</span>



         <h3  style="margin-top:20px;"><span class="blu" style= "font-size:16px;">Vineel Pratap</span> - Department Web Secretary </h3>



    <span class="h">vineel@aagomani.org</span>

    

         <h3  style="margin-top:20px;"><span class="blu" style= "font-size:16px;">Joy Khan </span> - Department Alumni Secretary </h3>



    <span class="h">joy@aagomani.org</span>

    

         <h3  style="margin-top:20px;"><span class="blu" style= "font-size:16px;">Alankar Jain</span> - Chief Editor </h3>



    <span class="h">alankar@aagomani.org</span>



        <br />

<br />

<br />





  



    </td>



  </tr>



</table>



















</p>



</div>



  </p>