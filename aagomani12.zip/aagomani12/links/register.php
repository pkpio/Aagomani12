
     <h1>REGISTER</h1> 

    <form style="margin:30px 0px 0px 24px;" method="post" action="register/index.php"> 

     <input type="text" class="textbox" name="emailid"  placeholder="Email-Id" align="center" title="Email Id" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

     <input type="text" class="textbox"  name="name" placeholder="Name" title="Name" /><br>

     <input type="password" class="textbox" name="password"  placeholder="Password" title="Password" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;

     <input type="password" class="textbox" name="repassword"  placeholder="Re-enter Password" title="Re-type Password" /><br>
	 
	 <input type="text" class="textbox" name="mobile"  placeholder="Mobile No."  maxlength="10" title="Mobile Number" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     
     <input type="text" class="textbox" name="city"  placeholder="City" title="City" /><br>
     
     <input type="text" class="textbox" name="college"  placeholder="College" title="College" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
     
     
     <select name="year" style="width:200px; height:30px; padding:6px;" title="Select your College year">
     <option value="Not selected" style="padding:6px;">Select your College year</option>
     <option value="1st year UG" style="padding:6px;">1st Year UnderGradute</option>
     <option value="2nd year UG" style="padding:6px;">2nd Year UnderGradute</option>
     <option value="3rd year UG" style="padding:6px;">3rd Year UnderGradute</option>
     <option value="4th year UG" style="padding:6px;">4th Year UnderGradute</option>
     <option value="5th year UG" style="padding:6px;">5th Year UnderGradute</option>
     <option value="1st year PG" style="padding:6px;">1st Year PostGradute</option>
     <option value="2nd year PG" style="padding:6px;">2nd Year PostGradute</option>
     <option value="Others" style="padding:6px;">Others</option></select><br>
     

     <textarea name="address" cols="40" rows="3"  placeholder="Address" title="Address" style="border:1px solid #999;	font-size:15px; padding:4px 0px 1px 5px;font-family: 'Droid Sans', Arial, sans-serif;"></textarea><br><br>

     <textarea name="remarks" cols="40" rows="3"  placeholder="Remarks" title="Remarks" style="border:1px solid #999;	font-size:15px; padding:4px 0px 1px 5px;font-family: 'Droid Sans', Arial, sans-serif;"></textarea><br><br>

     <input type="submit" name="reg" value="Register" class="button">

<p align="center" style="color:#666; font-size:10px;">**Registration fee of Rs.150 to be paid on the spot.</p>

    </form>
