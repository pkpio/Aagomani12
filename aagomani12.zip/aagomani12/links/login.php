
 <h1>LOGIN</h1> 

    <form style="margin:30px 0px 0px 24px;" method="post" action="user/login/">  

     <input type="text" class="textbox" name="email"  placeholder="Email-Id" align="center" /><br>

     <input type="password" class="textbox" name="password"  placeholder="Password" align="center" /><br>

     <input type="submit" name="reg" value="Login" class="button">

    </form>

	<br />
