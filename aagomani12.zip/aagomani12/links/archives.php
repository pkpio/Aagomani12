<h1>ARCHIVES</h1> 
<div id="archives">    
<table width="100%">
<tr>
<td style="padding:0px 28px 0px 0px;"><p><span class="blu" style="color:#23586a; font-weight:normal;">New Generation Robotics</span></p></td>

<td align="left"><li><a onclick="window.open('http://www.ee.iitb.ac.in/student/~eesa/aagomani11', '_newtab');" href="#">Aagomani 2011</a></li></td></tr> 



<tr>
<td style="padding:0px 28px 0px 0px;"><p><span class="blu" style="color:#23586a; font-weight:normal;">Wireless Technology and its Application</span></p></td>

<td align="left"><li><a onclick="window.open('http://www.ee.iitb.ac.in/student/~eesa/aagomani09', '_newtab1');" href="#">Aagomani 2009</a></li></td></tr> 




<tr><td style="padding:0px 28px 0px 0px;"><p><span class="blu" style="color:#23586a; font-weight:normal;">Electronics in Space</span></p></td>
<td align="left"><li><a onclick="window.open('http://www.ee.iitb.ac.in/student/~eesa/aagomani08', '_newtab2');" href="#">Aagomani 2008</a></li></td></tr> 


 
<tr><td style="padding:0px 28px 0px 0px;"><p><span class="blu" style="color:#23586a; font-weight:normal;">Multimedia and Digital Entertainment </span></p></td>

<td align="left"><li><a onclick="window.open('http://www.ee.iitb.ac.in/student/~eesa/aagomani07', '_newtab3');" href="#">Aagomani 2007</a></li></td></tr>




<tr><td style="padding:0px 28px 0px 0px;"><p><span class="blu" style="color:#23586a; font-weight:normal;">Super Computers & High Performance Computing</span></p></td>

<td align="left"><li><a onclick="window.open('http://www.ee.iitb.ac.in/student/~eesa/aagomani06', '_newtab4');" href="#">Aagomani 2006</a></li></td></tr>
  </table></div>