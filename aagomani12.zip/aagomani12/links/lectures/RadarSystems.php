<link rel="stylesheet" type="text/css" href="links/event-style.css" />
<script>
$(document).ready(function() {
document.getElementById("loadingImage").style.visibility="hidden";});
</script>


<h1>Radar Systems</h1>
<div id="tabDisplay">
<!-- Home tab content goes here --><br/>
              <h2 align="left">INTRODUCTION :</h2>
              <img src="images/RadarSystems.jpg" id="floatright" />
              <p>Defying ignorance has become a habit to us humans. We are not meant to walk blind. Neither is our brainchild - the aeroplane. Put humans with 20-20 vision in them all you want, but you're still headed for a fiery death. With visibility close to zero, and enemy aircrafts buzzing around you, you want a friend. RADAR.<br/>&nbsp;&nbsp;&nbsp;&nbsp;

Radar in peacetime has become as important to progress and evolution as radar in wartime. The modern uses of radar are highly diverse, including air traffic control, ocean and outer space surveillance and rendezvous systems, and flight control systems.<br/>&nbsp;&nbsp;&nbsp;&nbsp;

The lecture underlines the impact radar has had on today's automobiles, and drives home the concepts underlying radar technologies.
              </div>