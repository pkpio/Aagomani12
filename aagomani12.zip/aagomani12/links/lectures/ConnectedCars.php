<link rel="stylesheet" type="text/css" href="links/event-style.css" />
<script>
$(document).ready(function() {
document.getElementById("loadingImage").style.visibility="hidden";});
</script>


<h1>Connected Cars</h1>
<div id="tabDisplay">
<!-- Home tab content goes here --><br/>
              <h2 align="left">INTRODUCTION :</h2>
              <img src="images/ConnectedCars.jpg" id="floatright" />
              <p>Social networking for a cause - doesn't that sound great ?<br/>&nbsp;&nbsp;&nbsp;&nbsp;

Initiated by the Department of Transportation (DoT), USA, in collaboration with eight automobile giants, the Vehicle Safety Communications (VSC) project is set to become a mandatory norm in every future vehicle. Automobiles will talk to each other and to transportation infrastructure wirelessly using a short-range dedicated communicating network to get us home safely.<br/>&nbsp;&nbsp;&nbsp;&nbsp;

Brace yourself, as an expert leads you by your little finger into a world flitting between reality and fantasy - one in which cars possess unimaginable faculties that keep you both safe and comfortable.</p>
              </div>