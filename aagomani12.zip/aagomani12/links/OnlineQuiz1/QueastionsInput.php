<?php
//Set A....

//This is Queastion 1..... Queastion text comes between <p>...</p>
$OrderQstnSetA[0] = "<li><p>The tolerance band: gold , silver and brown represent ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 10 % , 5% , 1%
						 <input type='radio' name='answer' value='2' /> 5 %  , 10%, 2%
						 <input type='radio' name='answer' value='3' /> 5 % , 10% , 1%
						 <input type='radio' name='answer' value='4' /> 10 % , 5%, 2%</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[0] = "3";

//This is Queastion 2..... Queastion text comes between <p>...</p>
$OrderQstnSetA[1] = "<li><p>223 on a capacitor represents ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 0.022 uF 
						 <input type='radio' name='answer' value='2' /> 22 nF
						 <input type='radio' name='answer' value='3' /> 22000 pF
						 <input type='radio' name='answer' value='4' /> All of the above</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[1] = "4";

//This is Queastion 3..... Queastion text comes between <p>...</p>
$OrderQstnSetA[2] = "<li><p>The current requirement of a typical LED is ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 1-5 mA
						 <input type='radio' name='answer' value='2' /> 20-25mA
						 <input type='radio' name='answer' value='3' /> 30-35mA
						 <input type='radio' name='answer' value='4' /> 50-65 mA</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[2] = "1";


//This is Queastion 4..... Queastion text comes between <p>...</p>
$OrderQstnSetA[3] = "<li><p> Which motor is not suitable for use as DC machine ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Permanent magnet motor
						 <input type='radio' name='answer' value='2' /> Series Motor
						 <input type='radio' name='answer' value='3' /> Squirrel Cage Motor
						 <input type='radio' name='answer' value='4' /> Synchronous motor</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[3] = "4";


//This is Queastion 5..... Queastion text comes between <p>...</p>
$OrderQstnSetA[4] = "<li><p>Select the odd man out of the following:</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> J.Bardeen
						 <input type='radio' name='answer' value='2' /> W.Brattain
						 <input type='radio' name='answer' value='3' /> William Schockly
						 <input type='radio' name='answer' value='4' /> Jack Kilby</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[4] = "4";

//This is Queastion 6..... Queastion text comes between <p>...</p>
$OrderQstnSetA[5] = "<li><p>These Jargon terms mean  ‘mickey’ , ‘electro’ , ‘cap’ , ‘puff’…  ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> mighty, electronic ,capper ,picofarad
						 <input type='radio' name='answer' value='2' /> microfarad, electronic , capacitor, picofarad
						 <input type='radio' name='answer' value='3' /> microfarad , electrolytic,capacitor,picofarad
						 <input type='radio' name='answer' value='4' /> microfarad , electrolytic , capping , blow</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[5] = "2";	


//This is Queastion 7..... Queastion text comes between <p>...</p>
$OrderQstnSetA[6] = "<li><p>This characteristic’s modern unit of measurement is named after a german physicist ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Force
						 <input type='radio' name='answer' value='2' /> Frequency
						 <input type='radio' name='answer' value='3' /> Flux
						 <input type='radio' name='answer' value='4' /> Pressure</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[6] = "2";

//This is Queastion 8..... Queastion text comes between <p>...</p>
$OrderQstnSetA[7] = "<li><p>Select the odd man out of the following:</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Gordon Moore 
						 <input type='radio' name='answer' value='2' /> Robert Noyce
						 <input type='radio' name='answer' value='3' /> Andrew Grove
						 <input type='radio' name='answer' value='4' /> Ed Turney</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[7] = "4";

//This is Queastion 9..... Queastion text comes between <p>...</p>
$OrderQstnSetA[8] = "<li><p>The FFT , mathematical process extensively used in DSP .what word does the first ‘F’ in FFT stand for ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Fourier
						 <input type='radio' name='answer' value='2' /> Footed
						 <input type='radio' name='answer' value='3' /> Fast
						 <input type='radio' name='answer' value='4' /> Ford</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[8] = "3";


//This is Queastion 10..... Queastion text comes between <p>...</p>
$OrderQstnSetA[9] = "<li><p> Which of the following is not an effect of CMOS Scaling?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Integration density increases
						 <input type='radio' name='answer' value='2' /> Switching speed decreases
						 <input type='radio' name='answer' value='3' /> Switching speed increases
						 <input type='radio' name='answer' value='4' /> Power consumption decreases</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[9] = "3";


//This is Queastion 11..... Queastion text comes between <p>...</p>
$OrderQstnSetA[10] = "<li><p>What is the reason that Gate length in CMOS cannot be decreased beyond a limit?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> No increase of On-current (Drain Current)
						 <input type='radio' name='answer' value='2' /> Increase of Off-current (Subthreshold current)
						 <input type='radio' name='answer' value='3' /> No decrease of Gate Capacitance by Parasitic Components
						 <input type='radio' name='answer' value='4' /> Decrease of Off-current</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[10] = "4";

//This is Queastion 12..... Queastion text comes between <p>...</p>
$OrderQstnSetA[11] = "<li><p>Which is the first Indian company to start mobile telecommunication services for consumers in india ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> BSNL
						 <input type='radio' name='answer' value='2' /> Bharti
						 <input type='radio' name='answer' value='3' /> Reliance
						 <input type='radio' name='answer' value='4' /> Cellone</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[11] = "2";		


//This is Queastion 13..... Queastion text comes between <p>...</p>
$OrderQstnSetA[12] = "<li><p>GPS constellation has how many satellites</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 7
						 <input type='radio' name='answer' value='2' /> 21
						 <input type='radio' name='answer' value='3' /> 31
						 <input type='radio' name='answer' value='4' /> 45</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[12] = "3";

//This is Queastion 14..... Queastion text comes between <p>...</p>
$OrderQstnSetA[13] = "<li><p>You have been given thick & thin wires for connections. Which one you will use for connecting an ammeter & a voltmeter?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Thick-Ammeter , Thin-Voltmeter 
						 <input type='radio' name='answer' value='2' /> Thin-Voltmeter, Thick-Voltmeter
						 <input type='radio' name='answer' value='3' /> Both thin
						 <input type='radio' name='answer' value='4' /> Both thick</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[13] = "1";

//This is Queastion 15..... Queastion text comes between <p>...</p>
$OrderQstnSetA[14] = "<li><p>The most common format for a video home recorder is VHS. VHS stands for ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Video horizontal standard
						 <input type='radio' name='answer' value='2' /> Voltage house standard
						 <input type='radio' name='answer' value='3' /> Very high speed
						 <input type='radio' name='answer' value='4' /> Video home system</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[14] = "4";


//This is Queastion 16..... Queastion text comes between <p>...</p>
$OrderQstnSetA[15] = "<li><p> A motor suitable for signalling device is</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Induction motor
						 <input type='radio' name='answer' value='2' /> DC Shunt motor
						 <input type='radio' name='answer' value='3' /> DC Series motor
						 <input type='radio' name='answer' value='4' /> Reluctance motor</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[15] = "4";


//This is Queastion 17..... Queastion text comes between <p>...</p>
$OrderQstnSetA[16] = "<li><p>Typical number of erasable cycles in a flash device is</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 10
						 <input type='radio' name='answer' value='2' /> 10^10
						 <input type='radio' name='answer' value='3' /> 10^3 
						 <input type='radio' name='answer' value='4' /> 10^5</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[16] = "4";

//This is Queastion 18..... Queastion text comes between <p>...</p>
$OrderQstnSetA[17] = "<li><p>A memory rated with 1kB contains how many bits?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 1000
						 <input type='radio' name='answer' value='2' /> 8000
						 <input type='radio' name='answer' value='3' /> 1024
						 <input type='radio' name='answer' value='4' /> 8192</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[17] = "4";	


//This is Queastion 19..... Queastion text comes between <p>...</p>
$OrderQstnSetA[18] = "<li><p>Which of these is a Server grade processor?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Intel i-7 
						 <input type='radio' name='answer' value='2' /> Intel  Xeon
						 <input type='radio' name='answer' value='3' /> AMD Athalon
						 <input type='radio' name='answer' value='4' /> Core 2 Duo</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[18] = "2";

//This is Queastion 20..... Queastion text comes between <p>...</p>
$OrderQstnSetA[19] = "<li><p>A  typical CD  (700 Mb) can accommodate how many floppy disk types</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 50 
						 <input type='radio' name='answer' value='2' /> 100
						 <input type='radio' name='answer' value='3' /> 500
						 <input type='radio' name='answer' value='4' /> 1000</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[19] = "3";

//This is Queastion 21..... Queastion text comes between <p>...</p>
$OrderQstnSetA[20] = "<li><p>Which semi conductor material was used in making the first transistor ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Germanium
						 <input type='radio' name='answer' value='2' /> Silicon
						 <input type='radio' name='answer' value='3' /> Gallium Arsenide
						 <input type='radio' name='answer' value='4' /> Gallium Nitride</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[20] = "1";


//This is Queastion 22..... Queastion text comes between <p>...</p>
$OrderQstnSetA[21] = "<li><p> Most widely use micro processor ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Atmega 16
						 <input type='radio' name='answer' value='2' /> 8085
						 <input type='radio' name='answer' value='3' /> PIC
						 <input type='radio' name='answer' value='4' /> 8051</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[21] = "2";


//This is Queastion 23..... Queastion text comes between <p>...</p>
$OrderQstnSetA[22] = "<li><p>Generation capacity of india ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 100 GW
						 <input type='radio' name='answer' value='2' /> 170 GW
						 <input type='radio' name='answer' value='3' /> 300 GW
						 <input type='radio' name='answer' value='4' /> 600 GW</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[22] = "2";

//This is Queastion 24..... Queastion text comes between <p>...</p>
$OrderQstnSetA[23] = "<li><p>Which company’s license was not affected by recent supreme court ruling in 2G scam case ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Tata
						 <input type='radio' name='answer' value='2' /> Airtel
						 <input type='radio' name='answer' value='3' /> Uninor
						 <input type='radio' name='answer' value='4' /> Videocon</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[23] = "2";	

//This is Queastion 25..... Queastion text comes between <p>...</p>
$OrderQstnSetA[24] = "<li><p>How much capacitance does a finger typically create when using a capacitive touch sensor?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 5-15 nF
						 <input type='radio' name='answer' value='2' /> 5-15 pF
						 <input type='radio' name='answer' value='3' /> 5-15 uF
						 <input type='radio' name='answer' value='4' /> 5-15 mF</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetA[24] = "2";	
	
	
	
	
/*                      So on 30 queastions..Njoy :P Complete the NO image queastions for now. I will do the Image queastions..*/ 	
	
	
	
	
	
	
	
//Set B....
//This is Queastion 1..... Queastion text comes between <p>...</p>
//This is Queastion 1..... Queastion text comes between <p>...</p>
$OrderQstnSetB[0] = "<li><p>The tolerance band: gold , silver and brown represent ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 10 % , 5% , 1%
						 <input type='radio' name='answer' value='2' /> 5 %  , 10%, 2%
						 <input type='radio' name='answer' value='3' /> 5 % , 10% , 1%
						 <input type='radio' name='answer' value='4' /> 10 % , 5%, 2%</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[0] = "3";

//This is Queastion 2..... Queastion text comes between <p>...</p>
$OrderQstnSetB[1] = "<li><p>223 on a capacitor represents ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 0.022 uF 
						 <input type='radio' name='answer' value='2' /> 22 nF
						 <input type='radio' name='answer' value='3' /> 22000 pF
						 <input type='radio' name='answer' value='4' /> All of the above</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[1] = "4";

//This is Queastion 3..... Queastion text comes between <p>...</p>
$OrderQstnSetB[2] = "<li><p>The current requirement of a typical LED is ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 1-5 mA
						 <input type='radio' name='answer' value='2' /> 20-25mA
						 <input type='radio' name='answer' value='3' /> 30-35mA
						 <input type='radio' name='answer' value='4' /> 50-65 mA</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[2] = "1";


//This is Queastion 4..... Queastion text comes between <p>...</p>
$OrderQstnSetB[3] = "<li><p> Which motor is not suitable for use as DC machine ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Permanent magnet motor
						 <input type='radio' name='answer' value='2' /> Series Motor
						 <input type='radio' name='answer' value='3' /> Squirrel Cage Motor
						 <input type='radio' name='answer' value='4' /> Synchronous motor</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[3] = "4";


//This is Queastion 5..... Queastion text comes between <p>...</p>
$OrderQstnSetB[4] = "<li><p>Select the odd man out of the following:</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> J.Bardeen
						 <input type='radio' name='answer' value='2' /> W.Brattain
						 <input type='radio' name='answer' value='3' /> William Schockly
						 <input type='radio' name='answer' value='4' /> Jack Kilby</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[4] = "4";

//This is Queastion 6..... Queastion text comes between <p>...</p>
$OrderQstnSetB[5] = "<li><p>These Jargon terms mean  ‘mickey’ , ‘electro’ , ‘cap’ , ‘puff’…  ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> mighty, electronic ,capper ,picofarad
						 <input type='radio' name='answer' value='2' /> microfarad, electronic , capacitor, picofarad
						 <input type='radio' name='answer' value='3' /> microfarad , electrolytic,capacitor,picofarad
						 <input type='radio' name='answer' value='4' /> microfarad , electrolytic , capping , blow</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[5] = "2";	


//This is Queastion 7..... Queastion text comes between <p>...</p>
$OrderQstnSetB[6] = "<li><p>This characteristic’s modern unit of measurement is named after a german physicist ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Force
						 <input type='radio' name='answer' value='2' /> Frequency
						 <input type='radio' name='answer' value='3' /> Flux
						 <input type='radio' name='answer' value='4' /> Pressure</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[6] = "2";

//This is Queastion 8..... Queastion text comes between <p>...</p>
$OrderQstnSetB[7] = "<li><p>Select the odd man out of the following:</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Gordon Moore 
						 <input type='radio' name='answer' value='2' /> Robert Noyce
						 <input type='radio' name='answer' value='3' /> Andrew Grove
						 <input type='radio' name='answer' value='4' /> Ed Turney</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[7] = "4";

//This is Queastion 9..... Queastion text comes between <p>...</p>
$OrderQstnSetB[8] = "<li><p>The FFT , mathematical process extensively used in DSP .what word does the first ‘F’ in FFT stand for ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Fourier
						 <input type='radio' name='answer' value='2' /> Footed
						 <input type='radio' name='answer' value='3' /> Fast
						 <input type='radio' name='answer' value='4' /> Ford</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[8] = "3";


//This is Queastion 10..... Queastion text comes between <p>...</p>
$OrderQstnSetB[9] = "<li><p> Which of the following is not an effect of CMOS Scaling?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Integration density increases
						 <input type='radio' name='answer' value='2' /> Switching speed decreases
						 <input type='radio' name='answer' value='3' /> Switching speed increases
						 <input type='radio' name='answer' value='4' /> Power consumption decreases</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[9] = "3";


//This is Queastion 11..... Queastion text comes between <p>...</p>
$OrderQstnSetB[10] = "<li><p>What is the reason that Gate length in CMOS cannot be decreased beyond a limit?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> No increase of On-current (Drain Current)
						 <input type='radio' name='answer' value='2' /> Increase of Off-current (Subthreshold current)
						 <input type='radio' name='answer' value='3' /> No decrease of Gate Capacitance by Parasitic Components
						 <input type='radio' name='answer' value='4' /> Decrease of Off-current</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[10] = "4";

//This is Queastion 12..... Queastion text comes between <p>...</p>
$OrderQstnSetB[11] = "<li><p>Which is the first Indian company to start mobile telecommunication services for consumers in india ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> BSNL
						 <input type='radio' name='answer' value='2' /> Bharti
						 <input type='radio' name='answer' value='3' /> Reliance
						 <input type='radio' name='answer' value='4' /> Cellone</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[11] = "2";		


//This is Queastion 13..... Queastion text comes between <p>...</p>
$OrderQstnSetB[12] = "<li><p>GPS constellation has how many satellites</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 7
						 <input type='radio' name='answer' value='2' /> 21
						 <input type='radio' name='answer' value='3' /> 31
						 <input type='radio' name='answer' value='4' /> 45</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[12] = "3";

//This is Queastion 14..... Queastion text comes between <p>...</p>
$OrderQstnSetB[13] = "<li><p>You have been given thick & thin wires for connections. Which one you will use for connecting an ammeter & a voltmeter?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Thick-Ammeter , Thin-Voltmeter 
						 <input type='radio' name='answer' value='2' /> Thin-Voltmeter, Thick-Voltmeter
						 <input type='radio' name='answer' value='3' /> Both thin
						 <input type='radio' name='answer' value='4' /> Both thick</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[13] = "1";

//This is Queastion 15..... Queastion text comes between <p>...</p>
$OrderQstnSetB[14] = "<li><p>The most common format for a video home recorder is VHS. VHS stands for ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Video horizontal standard
						 <input type='radio' name='answer' value='2' /> Voltage house standard
						 <input type='radio' name='answer' value='3' /> Very high speed
						 <input type='radio' name='answer' value='4' /> Video home system</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[14] = "4";


//This is Queastion 16..... Queastion text comes between <p>...</p>
$OrderQstnSetB[15] = "<li><p> A motor suitable for signalling device is</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Induction motor
						 <input type='radio' name='answer' value='2' /> DC Shunt motor
						 <input type='radio' name='answer' value='3' /> DC Series motor
						 <input type='radio' name='answer' value='4' /> Reluctance motor</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[15] = "4";


//This is Queastion 17..... Queastion text comes between <p>...</p>
$OrderQstnSetB[16] = "<li><p>Typical number of erasable cycles in a flash device is</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 10
						 <input type='radio' name='answer' value='2' /> 10^10
						 <input type='radio' name='answer' value='3' /> 10^3 
						 <input type='radio' name='answer' value='4' /> 10^5</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[16] = "4";

//This is Queastion 18..... Queastion text comes between <p>...</p>
$OrderQstnSetB[17] = "<li><p>A memory rated with 1kB contains how many bits?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 1000
						 <input type='radio' name='answer' value='2' /> 8000
						 <input type='radio' name='answer' value='3' /> 1024
						 <input type='radio' name='answer' value='4' /> 8192</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[17] = "4";	


//This is Queastion 19..... Queastion text comes between <p>...</p>
$OrderQstnSetB[18] = "<li><p>Which of these is a Server grade processor?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Intel i-7 
						 <input type='radio' name='answer' value='2' /> Intel  Xeon
						 <input type='radio' name='answer' value='3' /> AMD Athalon
						 <input type='radio' name='answer' value='4' /> Core 2 Duo</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[18] = "2";

//This is Queastion 20..... Queastion text comes between <p>...</p>
$OrderQstnSetB[19] = "<li><p>A  typical CD  (700 Mb) can accommodate how many floppy disk types</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 50 
						 <input type='radio' name='answer' value='2' /> 100
						 <input type='radio' name='answer' value='3' /> 500
						 <input type='radio' name='answer' value='4' /> 1000</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[19] = "3";

//This is Queastion 21..... Queastion text comes between <p>...</p>
$OrderQstnSetB[20] = "<li><p>Which semi conductor material was used in making the first transistor ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Germanium
						 <input type='radio' name='answer' value='2' /> Silicon
						 <input type='radio' name='answer' value='3' /> Gallium Arsenide
						 <input type='radio' name='answer' value='4' /> Gallium Nitride</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[20] = "1";


//This is Queastion 22..... Queastion text comes between <p>...</p>
$OrderQstnSetB[21] = "<li><p> Most widely use micro processor ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Atmega 16
						 <input type='radio' name='answer' value='2' /> 8085
						 <input type='radio' name='answer' value='3' /> PIC
						 <input type='radio' name='answer' value='4' /> 8051</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[21] = "2";


//This is Queastion 23..... Queastion text comes between <p>...</p>
$OrderQstnSetB[22] = "<li><p>Generation capacity of india ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 100 GW
						 <input type='radio' name='answer' value='2' /> 170 GW
						 <input type='radio' name='answer' value='3' /> 300 GW
						 <input type='radio' name='answer' value='4' /> 600 GW</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[22] = "2";

//This is Queastion 24..... Queastion text comes between <p>...</p>
$OrderQstnSetB[23] = "<li><p>Which company’s license was not affected by recent supreme court ruling in 2G scam case ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Tata
						 <input type='radio' name='answer' value='2' /> Airtel
						 <input type='radio' name='answer' value='3' /> Uninor
						 <input type='radio' name='answer' value='4' /> Videocon</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[23] = "2";	

//This is Queastion 25..... Queastion text comes between <p>...</p>
$OrderQstnSetB[24] = "<li><p>How much capacitance does a finger typically create when using a capacitive touch sensor?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 5-15 nF
						 <input type='radio' name='answer' value='2' /> 5-15 pF
						 <input type='radio' name='answer' value='3' /> 5-15 uF
						 <input type='radio' name='answer' value='4' /> 5-15 mF</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetB[24] = "2";	
	







//Set C....
//This is Queastion 1..... Queastion text comes between <p>...</p>
$OrderQstnSetC[0] = "<li><p>The tolerance band: gold , silver and brown represent ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 10 % , 5% , 1%
						 <input type='radio' name='answer' value='2' /> 5 %  , 10%, 2%
						 <input type='radio' name='answer' value='3' /> 5 % , 10% , 1%
						 <input type='radio' name='answer' value='4' /> 10 % , 5%, 2%</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[0] = "3";

//This is Queastion 2..... Queastion text comes between <p>...</p>
$OrderQstnSetC[1] = "<li><p>223 on a capacitor represents ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 0.022 uF 
						 <input type='radio' name='answer' value='2' /> 22 nF
						 <input type='radio' name='answer' value='3' /> 22000 pF
						 <input type='radio' name='answer' value='4' /> All of the above</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[1] = "4";

//This is Queastion 3..... Queastion text comes between <p>...</p>
$OrderQstnSetC[2] = "<li><p>The current requirement of a typical LED is ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 1-5 mA
						 <input type='radio' name='answer' value='2' /> 20-25mA
						 <input type='radio' name='answer' value='3' /> 30-35mA
						 <input type='radio' name='answer' value='4' /> 50-65 mA</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[2] = "1";


//This is Queastion 4..... Queastion text comes between <p>...</p>
$OrderQstnSetC[3] = "<li><p> Which motor is not suitable for use as DC machine ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Permanent magnet motor
						 <input type='radio' name='answer' value='2' /> Series Motor
						 <input type='radio' name='answer' value='3' /> Squirrel Cage Motor
						 <input type='radio' name='answer' value='4' /> Synchronous motor</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[3] = "4";


//This is Queastion 5..... Queastion text comes between <p>...</p>
$OrderQstnSetC[4] = "<li><p>Select the odd man out of the following:</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> J.Bardeen
						 <input type='radio' name='answer' value='2' /> W.Brattain
						 <input type='radio' name='answer' value='3' /> William Schockly
						 <input type='radio' name='answer' value='4' /> Jack Kilby</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[4] = "4";

//This is Queastion 6..... Queastion text comes between <p>...</p>
$OrderQstnSetC[5] = "<li><p>These Jargon terms mean  ‘mickey’ , ‘electro’ , ‘cap’ , ‘puff’…  ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> mighty, electronic ,capper ,picofarad
						 <input type='radio' name='answer' value='2' /> microfarad, electronic , capacitor, picofarad
						 <input type='radio' name='answer' value='3' /> microfarad , electrolytic,capacitor,picofarad
						 <input type='radio' name='answer' value='4' /> microfarad , electrolytic , capping , blow</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[5] = "2";	


//This is Queastion 7..... Queastion text comes between <p>...</p>
$OrderQstnSetC[6] = "<li><p>This characteristic’s modern unit of measurement is named after a german physicist ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Force
						 <input type='radio' name='answer' value='2' /> Frequency
						 <input type='radio' name='answer' value='3' /> Flux
						 <input type='radio' name='answer' value='4' /> Pressure</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[6] = "2";

//This is Queastion 8..... Queastion text comes between <p>...</p>
$OrderQstnSetC[7] = "<li><p>Select the odd man out of the following:</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Gordon Moore 
						 <input type='radio' name='answer' value='2' /> Robert Noyce
						 <input type='radio' name='answer' value='3' /> Andrew Grove
						 <input type='radio' name='answer' value='4' /> Ed Turney</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[7] = "4";

//This is Queastion 9..... Queastion text comes between <p>...</p>
$OrderQstnSetC[8] = "<li><p>The FFT , mathematical process extensively used in DSP .what word does the first ‘F’ in FFT stand for ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Fourier
						 <input type='radio' name='answer' value='2' /> Footed
						 <input type='radio' name='answer' value='3' /> Fast
						 <input type='radio' name='answer' value='4' /> Ford</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[8] = "3";


//This is Queastion 10..... Queastion text comes between <p>...</p>
$OrderQstnSetC[9] = "<li><p> Which of the following is not an effect of CMOS Scaling?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Integration density increases
						 <input type='radio' name='answer' value='2' /> Switching speed decreases
						 <input type='radio' name='answer' value='3' /> Switching speed increases
						 <input type='radio' name='answer' value='4' /> Power consumption decreases</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[9] = "3";


//This is Queastion 11..... Queastion text comes between <p>...</p>
$OrderQstnSetC[10] = "<li><p>What is the reason that Gate length in CMOS cannot be decreased beyond a limit?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> No increase of On-current (Drain Current)
						 <input type='radio' name='answer' value='2' /> Increase of Off-current (Subthreshold current)
						 <input type='radio' name='answer' value='3' /> No decrease of Gate Capacitance by Parasitic Components
						 <input type='radio' name='answer' value='4' /> Decrease of Off-current</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[10] = "4";

//This is Queastion 12..... Queastion text comes between <p>...</p>
$OrderQstnSetC[11] = "<li><p>Which is the first Indian company to start mobile telecommunication services for consumers in india ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> BSNL
						 <input type='radio' name='answer' value='2' /> Bharti
						 <input type='radio' name='answer' value='3' /> Reliance
						 <input type='radio' name='answer' value='4' /> Cellone</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[11] = "2";		


//This is Queastion 13..... Queastion text comes between <p>...</p>
$OrderQstnSetC[12] = "<li><p>GPS constellation has how many satellites</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 7
						 <input type='radio' name='answer' value='2' /> 21
						 <input type='radio' name='answer' value='3' /> 31
						 <input type='radio' name='answer' value='4' /> 45</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[12] = "3";

//This is Queastion 14..... Queastion text comes between <p>...</p>
$OrderQstnSetC[13] = "<li><p>You have been given thick & thin wires for connections. Which one you will use for connecting an ammeter & a voltmeter?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Thick-Ammeter , Thin-Voltmeter 
						 <input type='radio' name='answer' value='2' /> Thin-Voltmeter, Thick-Voltmeter
						 <input type='radio' name='answer' value='3' /> Both thin
						 <input type='radio' name='answer' value='4' /> Both thick</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[13] = "1";

//This is Queastion 15..... Queastion text comes between <p>...</p>
$OrderQstnSetC[14] = "<li><p>The most common format for a video home recorder is VHS. VHS stands for ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Video horizontal standard
						 <input type='radio' name='answer' value='2' /> Voltage house standard
						 <input type='radio' name='answer' value='3' /> Very high speed
						 <input type='radio' name='answer' value='4' /> Video home system</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[14] = "4";


//This is Queastion 16..... Queastion text comes between <p>...</p>
$OrderQstnSetC[15] = "<li><p> A motor suitable for signalling device is</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Induction motor
						 <input type='radio' name='answer' value='2' /> DC Shunt motor
						 <input type='radio' name='answer' value='3' /> DC Series motor
						 <input type='radio' name='answer' value='4' /> Reluctance motor</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[15] = "4";


//This is Queastion 17..... Queastion text comes between <p>...</p>
$OrderQstnSetC[16] = "<li><p>Typical number of erasable cycles in a flash device is</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 10
						 <input type='radio' name='answer' value='2' /> 10^10
						 <input type='radio' name='answer' value='3' /> 10^3 
						 <input type='radio' name='answer' value='4' /> 10^5</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[16] = "4";

//This is Queastion 18..... Queastion text comes between <p>...</p>
$OrderQstnSetC[17] = "<li><p>A memory rated with 1kB contains how many bits?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 1000
						 <input type='radio' name='answer' value='2' /> 8000
						 <input type='radio' name='answer' value='3' /> 1024
						 <input type='radio' name='answer' value='4' /> 8192</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[17] = "4";	


//This is Queastion 19..... Queastion text comes between <p>...</p>
$OrderQstnSetC[18] = "<li><p>Which of these is a Server grade processor?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Intel i-7 
						 <input type='radio' name='answer' value='2' /> Intel  Xeon
						 <input type='radio' name='answer' value='3' /> AMD Athalon
						 <input type='radio' name='answer' value='4' /> Core 2 Duo</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[18] = "2";

//This is Queastion 20..... Queastion text comes between <p>...</p>
$OrderQstnSetC[19] = "<li><p>A  typical CD  (700 Mb) can accommodate how many floppy disk types</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 50 
						 <input type='radio' name='answer' value='2' /> 100
						 <input type='radio' name='answer' value='3' /> 500
						 <input type='radio' name='answer' value='4' /> 1000</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[19] = "3";

//This is Queastion 21..... Queastion text comes between <p>...</p>
$OrderQstnSetC[20] = "<li><p>Which semi conductor material was used in making the first transistor ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Germanium
						 <input type='radio' name='answer' value='2' /> Silicon
						 <input type='radio' name='answer' value='3' /> Gallium Arsenide
						 <input type='radio' name='answer' value='4' /> Gallium Nitride</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[20] = "1";


//This is Queastion 22..... Queastion text comes between <p>...</p>
$OrderQstnSetC[21] = "<li><p> Most widely use micro processor ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Atmega 16
						 <input type='radio' name='answer' value='2' /> 8085
						 <input type='radio' name='answer' value='3' /> PIC
						 <input type='radio' name='answer' value='4' /> 8051</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[21] = "2";


//This is Queastion 23..... Queastion text comes between <p>...</p>
$OrderQstnSetC[22] = "<li><p>Generation capacity of india ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 100 GW
						 <input type='radio' name='answer' value='2' /> 170 GW
						 <input type='radio' name='answer' value='3' /> 300 GW
						 <input type='radio' name='answer' value='4' /> 600 GW</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[22] = "2";

//This is Queastion 24..... Queastion text comes between <p>...</p>
$OrderQstnSetC[23] = "<li><p>Which company’s license was not affected by recent supreme court ruling in 2G scam case ?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> Tata
						 <input type='radio' name='answer' value='2' /> Airtel
						 <input type='radio' name='answer' value='3' /> Uninor
						 <input type='radio' name='answer' value='4' /> Videocon</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[23] = "2";	

//This is Queastion 25..... Queastion text comes between <p>...</p>
$OrderQstnSetC[24] = "<li><p>How much capacitance does a finger typically create when using a capacitive touch sensor?</p>
						 <p>
						 <input type='radio' name='answer' value='1' /> 5-15 nF
						 <input type='radio' name='answer' value='2' /> 5-15 pF
						 <input type='radio' name='answer' value='3' /> 5-15 uF
						 <input type='radio' name='answer' value='4' /> 5-15 mF</p></li>";
//This is the answer..Dont worry it wont be sent to the client anytime :P
$OrderAnsSetC[24] = "2";	
	
