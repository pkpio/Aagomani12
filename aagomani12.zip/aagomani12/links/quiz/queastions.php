<?php
$q1 = ""
?>

<ol>
<li><p>Test queastions with test options ?</p>
<p>
<input type="radio" name="a1" value="option1" /> option1
<input type="radio" name="a1" value="option2" /> option2
<input type="radio" name="a1" value="option3" /> option3
<input type="radio" name="a1" value="option4" /> option4</p></li>


<li><p>Test queastions with test options ?</p>
<p>
<input type="radio" name="a2" value="option1" /> option1
<input type="radio" name="a2" value="option2" /> option2
<input type="radio" name="a2" value="option3" /> option3
<input type="radio" name="a2" value="option4" /> option4</p></li>


<li><p>Test queastions with test options ?</p>
<p>
<input type="radio" name="a3" value="option1" /> option1
<input type="radio" name="a3" value="option2" /> option2
<input type="radio" name="a3" value="option3" /> option3
<input type="radio" name="a3" value="option4" /> option4</p></li>


<li><p>Test queastions with test options ?</p>
<p>
<input type="radio" name="a4" value="option1" /> option1
<input type="radio" name="a4" value="option2" /> option2
<input type="radio" name="a4" value="option3" /> option3
<input type="radio" name="a4" value="option4" /> option4</p></li>


<li><p>Decode the figure and write the answer</p>
<p><img src="../../images/header3.png" /></p>
<input type="text" name="a5" style="padding:5px; text-align:center" /></li>
</ol>
		
