<script>
$(document).ready(function() {
	  document.getElementById("loadingImage").style.visibility="hidden";})
</script>
<style>
#schedule td{
	width:200px;
	padding:20px;
	text-align:left;
}
</style>
<h1 align="left">Schedule</h1>
<table align="center" id="schedule">

<tr><td><span class="blu"><b>Time</b></span></td><td><span class="blu"><b>Event</b></span></td></tr>
<tr><td>8:00 a.m - 9:00 a.m</td><td>Registrations</td></tr>
<tr><td>9:00 a.m - 9:30 a.m</td><td>Introductory Note</td></tr>
<tr><td>9:30 a.m - 10:15 a.m</td><td>Talk on Radar systems</td></tr>
<tr><td>10:15 a.m - 11:00 a.m</td><td>Talk on Nano electronic</td></tr>
<tr><td>11:00 a.m - 12:30 p.m</td><td>Talent Expo</td></tr>
<tr><td>12:30 p.m - 1:00 p.m</td><td>Lunch</td></tr>
<tr><td>1:00 p.m - 1:30 p.m</td><td>Lunch, Nano fabrication Lab tour</td></tr>
<tr><td>1:30 p.m - 2:30 p.m</td><td>Nano fabrication Lab tour</td></tr>
<tr><td>1:30 p.m - 4:30 p.m</td><td>Workshops - Image Processing, Controls Workshop, E-Prayog(all 3 parallelly)</td></tr>
<tr><td>4:00 p.m - 5:00 p.m</td><td>Nano fabrication Lab tour</td></tr>
<tr><td>4:30 p.m - 5:00 p.m</td><td>Break</td></tr>
<tr><td>5:00 p.m - 6:00 p.m</td><td>Circuit Design challenge</td></tr>
<tr><td>5:00 p.m - 6:00 p.m</td><td>Competition - Auto Parking bot</td></tr>
<tr><td>6:00 p.m - 7:00 p.m</td><td>Quiz Finals</td></tr></table>
<br/>
<p>For any queries please contact the Managers. Thank you.</p>