<script>
$(document).ready(function() {
	  document.getElementById("loadingImage").style.visibility="hidden";})
</script>
 <h1>OUR PAST SPONSORS</h1>

 <style>

 img {padding: 5px;	border: solid 2px #CCC; float:left;}

 #img1{ height:115px; width:170px;}

 #img2{ height:110px; width:190px; margin-left:60px;}

 img:hover {border: solid 2px #999 ;

	-moz-box-shadow: 0px 0px 2px #999;

	-webkit-box-shadow: 0px 0px 2px #999;

        box-shadow: 0px 0px 2px #999;}

 </style>

<table width="100%" cellspacing="1" cellpadding="1" style="margin: 18px 0px  0px 10px; ">

  <tr>

    <td width="33%"><a href ="http://www.cisco.com/"  target="_new" ><img src="images/sponsors/cisco_logo.jpg" id="img1"></a></td>

    <td  width="33%"><a href ="http://www.intel.com/"  target="_new" ><img src="images/sponsors/intel_logo.jpg" id="img1"></a></td>

    <td  width="33%"><a href ="http://www.ibm.com/in/en/"  target="_new" ><img src="images/sponsors/ibm_logo.jpg" id="img1"></a></td>

  </tr>

</table>

<table width="100%" cellspacing="1" cellpadding="1" style="margin: 18px 0px  0px 10px; ">

  <tr>

    <td width="50%"><a href ="http://www.ni.com/"  target="_new" ><img src="images/sponsors/national-instruments_logo.jpg" id="img2"></a></td>

    <td  width="50%"><a href ="http://www.ti.com/"  target="_new" ><img src="images/sponsors/Texas-Instruments-logo-design.png" id="img2"></a></td>

  </tr>

</table>

<table width="100%" cellspacing="1" cellpadding="1" style="margin: 18px 0px  0px 10px; ">

  <tr>

    <td width="33%"><a href ="http://www.nvidia.com/"  target="_new" ><img src="images/sponsors/NVIDIA_logo.jpg" id="img1"></a></td>

    <td  width="33%"><a href ="http://www.virginmobile.in/"  target="_new" ><img src="images/sponsors/virgin_logo.jpg" id="img1"></a></td>

    <td  width="33%"><a href ="http://www.tataindicom.com/"  target="_new" ><img src="images/sponsors/tata_logo.jpg" id="img1"></a></td>

  </tr>

</table>

<table width="100%" cellspacing="1" cellpadding="1" style="margin: 18px 0px  0px 10px; ">

  <tr>

    <td width="50%"><a href ="http://www.tcs.com"  target="_new" ><img src="images/sponsors/tcs_logo.png" id="img2"></a></td>

    <td  width="50%"><a href ="http://www.imgtec.com/"  target="_new" ><img src="images/sponsors/Imagination-Technologies_logo.jpg" id="img2"></a></td>

  </tr>

</table>

<br />

<br />

