<script>
$(document).ready(function() {
	  document.getElementById("loadingImage").style.visibility="hidden";})
</script>
<OBJECT classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=6,0,40,0" WIDTH="720" HEIGHT="540" id="ElectricBox"><PARAM NAME=movie VALUE="http://games.mochiads.com/c/g/electric-box/ElectricBox.swf?affiliate_id=1c8e96a7a0a86d06"><PARAM NAME=quality VALUE=high><PARAM NAME=bgcolor VALUE=#FFFFFF><EMBED src="http://games.mochiads.com/c/g/electric-box/ElectricBox.swf?affiliate_id=1c8e96a7a0a86d06" quality=high bgcolor=#FFFFFF WIDTH="720" HEIGHT="540" NAME="ElectricBox" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer"></EMBED></OBJECT>