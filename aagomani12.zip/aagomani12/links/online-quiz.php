<?php
$require_once('quiz/queastions.php') ;
$require_once('quiz/answers.php') ;

?>