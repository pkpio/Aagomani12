<html>
  
  <p>   Electrical Engineering Students Association (EESA), IIT Bombay is organizing its annual 
technical festival in the field of wireless and cellular technology. Aagomani 2009 is being 
held at Electrical Engineering Department, IIT Bombay on the 10th and 11th of October 
2009. <br />
With lectures from top level executives of leading wireless and telecom industry and 
academicians from renowned institutes like IIT Bombay, we aim to gain an in-depth knowledge of the upcoming technologies, trends and innovations in the ever so popular field of 
wireless.<br />
 Aimed at both students and professionals, the 2 day event shall provide us with 
tools to understand what it takes to survive in an industry where innovation is a necessity, 
not a choice. Wireless World is the need of today and is one of the most talked about topics 
with new technologies being developed so frequently. The need to stay ahead in the competition and create devices which live up to the needs and requirements of the new-age generation is the challenge that lies ahead</p>
</div>
  </p>
  </html>