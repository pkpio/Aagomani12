<div id="fb-root"></div><script src="http://connect.facebook.net/en_US/all.js#appId=160030430746679&amp;xfbml=1"></script><fb:like href="http://www.ee.iitb.ac.in/student/~eesa/aagomani12" send="false" layout="button_count" width="450" show_faces="true" font="trebuchet ms"></fb:like>
    
    <div class="googleplusshare"> 
    <g:plusone size="medium" href="http://www.ee.iitb.ac.in/student/~eesa/aagomani12"></g:plusone> 
<script type="text/javascript"> 
  (function() {
    var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
    po.src = 'https://apis.google.com/js/plusone.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
  })();
</script> 
    </div> 
 
    <div class="twittershare"> 
    <a href="http://twitter.com/share" class="twitter-share-button" data-text="Check out AAKAAR - the Civil Engineering Festival of IIT Bombay" data-count="horizontal" data-via="AAKAAR_IITB">Tweet</a><script type="text/javascript" src="http://platform.twitter.com/widgets.js"></script> 
    </div>
