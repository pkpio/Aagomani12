<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />

</head>

<body>

<div id="menu">

    	<li><a id="home" href="#home" name="Aagomani 2012"><h5>HOME</h5><div>HOME</div></a></li>

 		<li><a id="schedule" href="#schedule" name="Schedule"><h5>SCHEDULE</h5><div>SCHEDULE</div></a></li>

 		<li><a id="competitions" href="#competitions" name="Competitions"><h5>COMPETITIONS</h5><div>COMPETITIONS</div></a></li>

	    <li><a id="lectures" href="#lectures" name="Lectures"><h5>LECTURES</h5><div>LECTURES</div></a></li>

        <li><a id="workshops" href="#workshops" name="Workshops"><h5>WORKSHOPS</h5><div>WORKSHOPS</div></a></li>

        <li><a id="OnlineQuiz" href="#OnlineQuiz" name="InterCollegeQuiz"><h5>InterCollegeQuiz</h5><div>InterCollegeQuiz</div></a></li>

        <li><a id="TalentExpo" href="#TalentExpo" name="Talent Expo"><h5>TALENT EXPO</h5><div>TALENT EXPO</div></a></li>

		<li><a id="sponsors" href="#sponsors" name="Sponsors"><h5>SPONSORS</h5><div>SPONSORS</div></a></li>

        <li><a id="contact" href="#contact" name="Contact"><h5>CONTACT</h5><div>CONTACT</div></a></li>

</div>

</body>

</html>